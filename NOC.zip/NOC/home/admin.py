from django.contrib import admin
from .models import Icccomplaints,Ncdcomplaint,Seacomplaint,Cccomplaint,Acscomplaint,Sqcomplaint,Contact

# Register your models here.
admin.site.register(Icccomplaints)
admin.site.register(Ncdcomplaint)
admin.site.register(Seacomplaint)
admin.site.register(Cccomplaint)
admin.site.register(Acscomplaint)
admin.site.register(Sqcomplaint)
admin.site.register(Contact)