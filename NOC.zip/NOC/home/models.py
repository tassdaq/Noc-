from django.db import models
from datetime import date
from django.contrib.auth.models import User

# Create your models here.

class Icccomplaints(models.Model):
    tokenid = models.AutoField(primary_key =True)
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    typeofcomplaint = models.CharField(max_length=100)
    complaintlevel = models.CharField(max_length=100, default="L1")
    status = models.CharField(max_length=50, default="Pending")
    date = models.DateField()

def __str__(self):
    return self.username

class Ncdcomplaint(models.Model):
    tokenid = models.AutoField(primary_key =True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    typeofcomplaint = models.CharField(max_length=100)
    complaintlevel = models.CharField(max_length=100, default="L1")
    status = models.CharField(max_length=50, default="Pending")
    date = models.DateField()

def __str__(self):
    return self.clientname


class Seacomplaint(models.Model):
    tokenid = models.AutoField(primary_key =True)
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    typeofcomplaint = models.CharField(max_length=100)
    complaintlevel = models.CharField(max_length=100, default="L1")
    status = models.CharField(max_length=50, default="Pending")
    date = models.DateField()

def __str__(self):
    return self.clientname


class Cccomplaint(models.Model):
    tokenid = models.AutoField(primary_key =True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    typeofcomplaint = models.CharField(max_length=100)
    complaintlevel = models.CharField(max_length=100, default="L1")
    status = models.CharField(max_length=50, default="Pending")
    date = models.DateField()

def __str__(self):
    return self.clientname


class Acscomplaint(models.Model):
    tokenid = models.AutoField(primary_key =True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    typeofcomplaint = models.CharField(max_length=100)
    complaintlevel = models.CharField(max_length=100, default="L1")
    status = models.CharField(max_length=50, default="Pending")
    date = models.DateField()

def __str__(self):
    return self.clientname


class Sqcomplaint(models.Model):
    tokenid = models.AutoField(primary_key =True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    typeofcomplaint = models.CharField(max_length=100)
    complaintlevel = models.CharField(max_length=100, default="L1")
    status = models.CharField(max_length=50, default="Pending")
    date = models.DateField()

def __str__(self):
    return self.clientname

    
class Contact(models.Model):
    name = models.CharField(max_length = 30)
    email = models.CharField(max_length = 30)
    phone = models.CharField(max_length = 30)
    desc = models.CharField(max_length = 200)
    date = models.DateField()


    def __str__(self) :
        return self.name                      


