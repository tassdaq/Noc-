from django.shortcuts import render,redirect, HttpResponse

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .models import Icccomplaints, Ncdcomplaint,Seacomplaint,Cccomplaint,Acscomplaint,Sqcomplaint,Contact
from datetime import datetime
from django.db.models import Max





# Create your views here.


def index(request):
    return render(request,("departments.html"))

def loginuser(request):
     if request.method =="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request,username= username, password= password)
        
        if user is not None:
    # A backend authenticated the credentials
            login(request,user)
            
            return redirect ("/userprofile")
        else:

           
            return redirect("/login") 
        
    
     return render(request,("login.html"))




def logoutuser(request):
    
        logout(request)
        messages.success(request,"Successfully Logout")
        return redirect("/login") 
      

def userregistration(request):
    if request.method =="POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password1 = request.POST.get('password1')

        if password!=password1:
         messages.error(request,"Your Password is not same")

        else:    

         my_user = User.objects.create_user(username,email,password)
         my_user.save()
         return redirect('login')
    return render (request,("user.html"))     

def ipcoreicc(request):
    if request.method =="POST":
        user = request.user
        typeofcomplaint = request.POST.get('typeofcomplaint')
        complaintlevel = request.POST.get('complaintlevel')
        status = request.POST.get('status')

        icccomplaint = Icccomplaints(user = user,typeofcomplaint = typeofcomplaint, complaintlevel = complaintlevel, status = status, date = datetime.today() )
        icccomplaint.save()
        messages.success(request,"Your Complaints has been Successfully")
        return redirect("/ipcoreicc")

    else:
     return render(request,("ipcoreicc.html"))

def boss(request):
    all = Icccomplaints.objects.all().count()
    ncd = Ncdcomplaint.objects.all().count()
    seacom = Seacomplaint.objects.all().count()
    com = Cccomplaint.objects.all().count()
    acss = Acscomplaint.objects.all().count()
    sqs = Sqcomplaint.objects.all().count()
    
  
  
    return render (request,'bossportal.html',{'all': all,'ncd' : ncd , 'seacom':seacom , 'com':com, 'acss':acss , 'sqs':sqs})    


def ipcorencd(request):
    if request.method =="POST":

        user = request.user
        typeofcomplaint = request.POST.get('typeofcomplaint')
        complaintlevel = request.POST.get('complaintlevel')
        status = request.POST.get('status')

        ncdcomplaint = Ncdcomplaint(user = user, typeofcomplaint = typeofcomplaint, complaintlevel = complaintlevel, status = status, date = datetime.today() )
        ncdcomplaint.save()
        messages.success(request,"Your Complaints has been Successfully")


    return render(request,("ipcorencd.html"))

       

def systememail(request):
    if request.method =="POST":

        user = request.user
        typeofcomplaint = request.POST.get('typeofcomplaint')
        complaintlevel = request.POST.get('complaintlevel')
        status = request.POST.get('status')

        seacomplaint = Seacomplaint(user= user, typeofcomplaint = typeofcomplaint, complaintlevel = complaintlevel, status = status, date = datetime.today() )
        seacomplaint.save()
        messages.success(request,"Your Complaints has been Successfully")

    return render(request,("systememail.html"))


def solution(request):
    if request.method =="POST":

        user = request.user
        typeofcomplaint = request.POST.get('typeofcomplaint')
        complaintlevel = request.POST.get('complaintlevel')
        status = request.POST.get('status')

        sqcomplaint = Sqcomplaint(user = user, typeofcomplaint = typeofcomplaint, complaintlevel = complaintlevel, status = status, date = datetime.today() )
        sqcomplaint.save()
        messages.success(request,"Your Complaints has been Successfully")

    return render(request,("solution.html"))

   

def cloud(request):
    if request.method =="POST":

        user = request.user
        typeofcomplaint = request.POST.get('typeofcomplaint')
        complaintlevel = request.POST.get('complaintlevel')
        status = request.POST.get('status')

        cccomplaint = Cccomplaint(user=user, typeofcomplaint = typeofcomplaint, complaintlevel = complaintlevel, status = status, date = datetime.today() )
        cccomplaint.save()
        messages.success(request,"Your Complaints has been Successfully")

    return render(request,("cloud.html"))

    

def activation(request):
    if request.method =="POST":

        user = request.user
        typeofcomplaint = request.POST.get('typeofcomplaint')
        complaintlevel = request.POST.get('complaintlevel')
        status = request.POST.get('status')

        acscomplaint = Acscomplaint(user=user, typeofcomplaint = typeofcomplaint, complaintlevel = complaintlevel, status = status, date = datetime.today() )
        acscomplaint.save()
        messages.success(request,"Your Complaints has been Successfully")

    return render(request,("activation.html"))


               

def userprofile(request):
    return render(request,("userprofile.html"))    


def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc =  request.POST.get('desc')
        contacts = Contact(name = name, email = email,phone = phone, desc = desc , date = datetime.today())
        contacts.save() 
        messages.success (request, 'Your message has been sent')  
    return render(request,('contact.html'))    




  








def logoutboss(request):
    
        logout(request)
        messages.success(request,"Successfully Logout")
        return redirect("/boss")  

def employees(request):
    return render(request,("employees.html"))   

def ipemployees(request):
    return render(request,("ipemployees.html"))            

def icc(request):
    allicc = Icccomplaints.objects.filter(user =request.user)
    context = {'icc': allicc}
    return render(request, 'icc.html',context)

def icccomplaint(request):
    all = Icccomplaints.objects.all()
    context = {'icccomplaint': all}
    return render(request,'bossportal',context)
    

def ncd(request):
    allncd = Ncdcomplaint.objects.filter(user = request.user)
    context = {'ncdrecord': allncd}
    return render(request, 'ncd.html',context)
  


def sea(request):
    allsea = Seacomplaint.objects.filter(user = request.user)
    context = {'seacomplaintrecord': allsea}
    return render(request, 'sea.html',context)
     

def cc(request):
    allcc = Cccomplaint.objects.filter(user = request.user)
    context = {'ccrecord': allcc}
    return render(request, 'cc.html',context) 
  

def acs(request):
    allacs = Acscomplaint.objects.filter(user = request.user)
    context = {'acsrecord': allacs}
    return render(request, 'acs.html',context) 
   

def sq(request):
    allsq = Sqcomplaint.objects.filter(user = request.user)
    context = {'sqrecord': allsq}
    return render(request, 'sq.html',context)
 

def empregistration(request):
    return render(request,("empregistration.html"))                   

def departments(request):
    allicc = Icccomplaints.objects.all()
    context = {'icc': allicc}
    return render(request, 'departments.html',context)


def example(request):
    return render(request,("example.html"))


              





def ncdregistration(request):
    return render(request,("ncdregistration.html"))          

def searegistration(request):
    return render(request,("searegistration.html")) 

def ccregistration(request):
    return render(request,("ccregistration.html")) 

def acsregistration(request):
    return render(request,("acsregistration.html"))   

def sqregistration(request):
    return render(request,("sqregistration.html"))    

def engregistration(request):
    return render(request,("engregistration.html"))                                      

def base(request):
    return render(request,("base.html"))   


def employeesicc(request):
    allicc = Icccomplaints.objects.all()
    context = {'icc': allicc}
    return render(request, 'employeesicc.html',context)
      

def employeesncd(request):
    allncd = Ncdcomplaint.objects.all()
    context = {'ncdrecord': allncd}
    return render(request, 'employeesncd.html',context)
     

def employeessea(request):
    allsea = Seacomplaint.objects.all()
    context = {'seacomplaintrecord': allsea}
    return render(request, 'employeessea.html',context)
    

def employeescc(request):
    allcc = Cccomplaint.objects.all()
    context = {'ccrecord': allcc}
    return render(request, 'employeescc.html',context) 
  

def employeesacs(request):
    allacs = Acscomplaint.objects.all()
    context = {'acsrecord': allacs}
    return render(request, 'employeesacs.html',context) 
    

def employeessq(request):
    allsq = Sqcomplaint.objects.all()
    context = {'sqrecord': allsq}
    return render(request, 'employeessq.html',context)
   
def useripcore(request):
    return render(request,("useripcore.html"))
   
def registrationcomplaint(request):
    return render(request,("registeredcomplaint.html"))

def ipregistrationcomplaint(request):
    return render(request,("ipregistrationcomplaint.html"))    

def deleteacs(request, tokenid):
    acs = Acscomplaints.objects.get(tokenid =tokenid)
    acs.delete()
    return redirect("/employeesacs")    

def deleteicc(request, tokenid):
    acs = Icccomplaints.objects.get(tokenid =tokenid)
    acs.delete()
    return redirect("/employeesicc")

def deletencd(request, tokenid):
    acs = Ncdcomplaints.objects.get(tokenid =tokenid)
    acs.delete()
    return redirect("/employeesncd")    

def deletesea(request, tokenid):
    acs = Seacomplaints.objects.get(tokenid =tokenid)
    acs.delete()
    return redirect("/employeessea") 

def deletesq(request, tokenid):
    acs = Sqcomplaints.objects.get(tokenid =tokenid)
    acs.delete()
    return redirect("/employeessq")  

def deletecc(request, tokenid):
    acs = Cccomplaints.objects.get(tokenid =tokenid)
    acs.delete()
    return redirect("/employeescc")                  

